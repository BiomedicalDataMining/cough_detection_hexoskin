#!/usr/bin/python3

import gzip,pickle

pkl_raw='data_raw.pkl.zip'
with gzip.open(pkl_raw) as fp:
    datapkl_raw = pickle.load(fp)


import ipdb
ipdb.set_trace()



