# Description
Original data found in /Google Drive/Hexoskin_Protocoles/Rapports_Techniques/Cough_protocol
git@bitbucket.org:carre/cough_detection.git